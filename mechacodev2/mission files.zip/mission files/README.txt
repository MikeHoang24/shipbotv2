example1.txt:

Turn gate valve at station A to 175 degrees
Breaker box A is at station C: ensure the second switch is off
Ensure shuttlecock valve at station D is closed
Breaker box B is at station F: ensure the third switch off
Turn gate valve at station G to 50 degrees
The target completion time is 360 seconds


example2.txt:

Ensure shuttlecock valve at station B is closed
Breaker box B is at station C: ensure the first switch is off
Breaker box B is at station C: ensure the second switch is off
Breaker box A is at station E: ensure the first switch is off
Turn (large) gate valve at station F to 60 degrees
The target completion time is 330 seconds


example3.txt:

Ensure shuttlecock valve at station A is open
Breaker box A is at station B: ensure the first switch is off
Turn gate valve at station D to 90 degrees
Turn (large) gate valve at station E to 45 degrees
Turn gate valve at station F to 185 degrees
The target completion time is 360 seconds


example4.txt:

Turn (large) gate valve at station B to 30 degrees
Breaker box B is at station C: ensure the first switch is off
Turn gate valve at station D to 60 degrees
Breaker box A is at station E: ensure the second switch is off
Target completion time is 320 seconds


example5.txt

Breaker box A is at station A: ensure first switch is off
Breaker box A is at station A: ensure third switch is off
Ensure shuttlecock valve at station B is closed
Turn gate valve at station C to 0 degrees
Breaker box B is at station D: ensure second switch is off
Turn gate valve at station E to 90 degrees
Target completion time is 450 seconds
